"use strict";(()=>{var v=Object.defineProperty;var y=(n,t,e)=>t in n?v(n,t,{enumerable:!0,configurable:!0,writable:!0,value:e}):n[t]=e;var r=(n,t,e)=>(y(n,typeof t!="symbol"?t+"":t,e),e);var m=["Is this a conscious choice?","What are you avoiding right now?","Take a deep breath.","Will this bring you closer to your goals?","How will you feel after spending time here?","What could you be doing instead?","Is this the best use of your time?","Are you running toward something or away from something?","What would your future self say?","Is this scroll going to add value to your day?","Pause. Breathe. Choose intentionally.","What brought you here right now?","Is this a habit or a decision?","How much time do you want to spend here?","Are you seeking connection or distraction?","What do you really need right now?","Is there something more meaningful calling you?","This moment is a choice. Choose wisely.","Breathe in possibility. Breathe out distraction.","You are in control of your attention."];function g(){let n=Math.floor(Math.random()*m.length);return m[n]}var l={blacklist:["twitter.com","x.com","facebook.com","instagram.com","reddit.com","tiktok.com","youtube.com"],pauseDuration:10,unlockDuration:15,theme:"system"},d={temptationsResisted:0,intentionalVisits:0},u={unlockedDomains:{}},o={SETTINGS:"settings",STATS:"stats",SESSIONS:"sessions"};function a(n){return n.toLowerCase().replace(/^www\./,"")}function p(n,t){let e=a(n);return t.some(i=>{let s=a(i);return!!(e===s||e.endsWith("."+s))})}function b(n,t){let e=a(n),i=t[e];return i?Date.now()<i:!1}function f(n){return n==="system"?window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light":n}var S=`
:host {
  all: initial;
  font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
}

*, *::before, *::after {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

.nudge-overlay {
  position: fixed;
  inset: 0;
  z-index: 2147483647;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  opacity: 0;
  transition: opacity 0.4s ease-out;
  overflow: hidden;
}

.nudge-overlay.visible {
  opacity: 1;
}

/* Light Theme - Soft greys and mint */
.nudge-overlay.theme-light {
  background: rgba(250, 250, 250, 0.97);
  color: #2d3748;
}

/* Dark Theme - Deep charcoal with muted teal */
.nudge-overlay.theme-dark {
  background: rgba(26, 32, 44, 0.98);
  color: #e2e8f0;
}

.nudge-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: clamp(1.5rem, 4vh, 3rem);
  max-width: 90vw;
  width: 100%;
  padding: clamp(1.5rem, 4vw, 3rem);
  text-align: center;
}

/* Breathing Circle */
.breathing-circle-container {
  position: relative;
  width: clamp(140px, 25vmin, 200px);
  height: clamp(140px, 25vmin, 200px);
  display: flex;
  align-items: center;
  justify-content: center;
}

.breathing-circle {
  width: 60%;
  height: 60%;
  border-radius: 50%;
  animation: breathe 8s ease-in-out infinite;
}

.theme-light .breathing-circle {
  background: linear-gradient(135deg, #81e6d9 0%, #4fd1c5 50%, #38b2ac 100%);
  box-shadow: 0 0 60px rgba(79, 209, 197, 0.4);
}

.theme-dark .breathing-circle {
  background: linear-gradient(135deg, #4fd1c5 0%, #319795 50%, #2c7a7b 100%);
  box-shadow: 0 0 60px rgba(79, 209, 197, 0.3);
}

@keyframes breathe {
  0%, 100% {
    transform: scale(1);
    opacity: 0.8;
  }
  50% {
    transform: scale(1.5);
    opacity: 1;
  }
}

/* Timer */
.timer {
  position: absolute;
  font-size: clamp(2rem, 5vmin, 2.5rem);
  font-weight: 300;
  letter-spacing: 0.05em;
  font-variant-numeric: tabular-nums;
}

.theme-light .timer {
  color: #2d3748;
}

.theme-dark .timer {
  color: #f7fafc;
}

/* Prompt */
.prompt {
  font-size: clamp(1.25rem, 3vmin, 1.5rem);
  font-weight: 400;
  line-height: 1.6;
  max-width: 400px;
  opacity: 0.9;
}

.theme-light .prompt {
  color: #4a5568;
}

.theme-dark .prompt {
  color: #cbd5e0;
}

/* Breathing instruction */
.breathing-text {
  font-size: clamp(0.75rem, 1.5vmin, 0.875rem);
  font-weight: 400;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  opacity: 0.6;
  animation: breatheText 8s ease-in-out infinite;
}

.theme-light .breathing-text {
  color: #718096;
}

.theme-dark .breathing-text {
  color: #a0aec0;
}

@keyframes breatheText {
  0%, 45%, 100% { opacity: 0.4; }
  22.5% { opacity: 0.8; }
  72.5% { opacity: 0.8; }
}

/* Buttons */
.buttons-container {
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
  width: 100%;
  max-width: 260px;
  margin-top: clamp(0.5rem, 2vh, 1rem);
}

.nudge-btn {
  padding: 0.875rem 1.5rem;
  font-size: 0.9375rem;
  font-weight: 500;
  border-radius: 12px;
  border: none;
  cursor: pointer;
  font-family: inherit;
  transition: all 0.2s ease;
  -webkit-tap-highlight-color: transparent;
}

.nudge-btn:focus {
  outline: none;
}

.nudge-btn:focus-visible {
  outline: 2px solid #4fd1c5;
  outline-offset: 2px;
}

/* Continue Button */
.continue-btn {
  opacity: 0;
  transform: translateY(10px);
  pointer-events: none;
  transition: opacity 0.4s ease, transform 0.4s ease;
}

.continue-btn.visible {
  opacity: 1;
  transform: translateY(0);
  pointer-events: auto;
}

.theme-light .continue-btn {
  background: linear-gradient(135deg, #4fd1c5 0%, #38b2ac 100%);
  color: white;
  box-shadow: 0 4px 14px rgba(79, 209, 197, 0.3);
}

.theme-light .continue-btn:hover {
  box-shadow: 0 6px 20px rgba(79, 209, 197, 0.4);
  transform: translateY(-2px);
}

.theme-light .continue-btn:active {
  transform: scale(0.98);
}

.theme-dark .continue-btn {
  background: linear-gradient(135deg, #319795 0%, #2c7a7b 100%);
  color: white;
  box-shadow: 0 4px 14px rgba(49, 151, 149, 0.3);
}

.theme-dark .continue-btn:hover {
  box-shadow: 0 6px 20px rgba(49, 151, 149, 0.4);
  transform: translateY(-2px);
}

.theme-dark .continue-btn:active {
  transform: scale(0.98);
}

/* Close Button */
.close-btn {
  background: transparent;
  border: 2px solid currentColor;
  opacity: 0.7;
}

.theme-light .close-btn {
  color: #718096;
}

.theme-light .close-btn:hover {
  background: rgba(113, 128, 150, 0.1);
  opacity: 1;
}

.theme-dark .close-btn {
  color: #a0aec0;
}

.theme-dark .close-btn:hover {
  background: rgba(160, 174, 192, 0.1);
  opacity: 1;
}

/* Reduced motion */
@media (prefers-reduced-motion: reduce) {
  .breathing-circle {
    animation: none;
    transform: scale(1.2);
    opacity: 0.85;
  }

  .breathing-text {
    animation: none;
    opacity: 0.6;
  }

  .nudge-overlay,
  .continue-btn,
  .nudge-btn {
    transition: none;
  }
}
`,c=class{constructor(){r(this,"shadowHost",null);r(this,"shadowRoot",null);r(this,"timerInterval",null);r(this,"settings",{...l});r(this,"currentDomain");r(this,"mutationObserver",null);r(this,"handleKeyDown",t=>{t.key==="Escape"&&this.shadowHost&&this.handleClose()});this.currentDomain=a(window.location.hostname)}async init(){try{if(await this.loadSettings(),!this.shouldCheckDomain())return;await this.shouldShowNudge()&&this.injectOverlay(),this.listenForChanges()}catch{}}shouldCheckDomain(){let t=window.location.protocol;return!(t!=="http:"&&t!=="https:"||!this.settings.blacklist.length)}async loadSettings(){let t=await chrome.storage.sync.get(o.SETTINGS);t[o.SETTINGS]&&(this.settings={...l,...t[o.SETTINGS]})}async shouldShowNudge(){if(!p(this.currentDomain,this.settings.blacklist))return!1;let e=(await chrome.storage.local.get(o.SESSIONS))[o.SESSIONS]||u;return!b(this.currentDomain,e.unlockedDomains)}listenForChanges(){chrome.storage.onChanged.addListener((t,e)=>{e==="sync"&&t[o.SETTINGS]&&(this.settings={...l,...t[o.SETTINGS].newValue}),e==="local"&&t[o.SESSIONS]&&this.handleSessionChange()})}async handleSessionChange(){let t=await this.shouldShowNudge();t&&!this.shadowHost?this.injectOverlay():!t&&this.shadowHost&&this.removeOverlay()}injectOverlay(){document.body.style.overflow="hidden",this.shadowHost=document.createElement("div"),this.shadowHost.id="nudge-overlay-host",this.shadowHost.setAttribute("aria-hidden","false"),this.shadowHost.style.cssText=`
      position: fixed !important;
      inset: 0 !important;
      z-index: 2147483647 !important;
      pointer-events: auto !important;
    `,this.shadowRoot=this.shadowHost.attachShadow({mode:"closed"});let t=document.createElement("style");t.textContent=S,this.shadowRoot.appendChild(t);let e=f(this.settings.theme),i=g(),s=document.createElement("div");s.className=`nudge-overlay theme-${e}`,s.setAttribute("role","dialog"),s.setAttribute("aria-modal","true"),s.setAttribute("aria-label","Mindfulness pause"),s.innerHTML=`
      <div class="nudge-container">
        <span class="breathing-text" aria-hidden="true">Breathe</span>
        <div class="breathing-circle-container">
          <div class="breathing-circle" aria-hidden="true"></div>
          <span class="timer" role="timer" aria-live="polite">${this.settings.pauseDuration}</span>
        </div>
        <p class="prompt">${i}</p>
        <div class="buttons-container">
          <button class="nudge-btn continue-btn" disabled aria-disabled="true">Continue to Site</button>
          <button class="nudge-btn close-btn">Close Tab</button>
        </div>
      </div>
    `,this.shadowRoot.appendChild(s),document.documentElement.appendChild(this.shadowHost),requestAnimationFrame(()=>{requestAnimationFrame(()=>{s.classList.add("visible")})}),this.startTimer(),this.setupEventHandlers(),this.setupMutationObserver()}startTimer(){if(!this.shadowRoot)return;let t=this.settings.pauseDuration,e=this.shadowRoot.querySelector(".timer"),i=this.shadowRoot.querySelector(".continue-btn");this.timerInterval=window.setInterval(()=>{t--,e&&(e.textContent=t>0?String(t):""),t<=0&&(this.clearTimer(),i&&(i.disabled=!1,i.removeAttribute("aria-disabled"),i.classList.add("visible"),i.focus()))},1e3)}clearTimer(){this.timerInterval&&(clearInterval(this.timerInterval),this.timerInterval=null)}setupEventHandlers(){if(!this.shadowRoot)return;let t=this.shadowRoot.querySelector(".continue-btn"),e=this.shadowRoot.querySelector(".close-btn");t?.addEventListener("click",()=>this.handleContinue()),e?.addEventListener("click",()=>this.handleClose()),document.addEventListener("keydown",this.handleKeyDown)}async handleContinue(){try{let e=(await chrome.storage.local.get(o.SESSIONS))[o.SESSIONS]||{...u},i=this.settings.unlockDuration*60*1e3;e.unlockedDomains[this.currentDomain]=Date.now()+i,await chrome.storage.local.set({[o.SESSIONS]:e});let h=(await chrome.storage.sync.get(o.STATS))[o.STATS]||{...d};h.intentionalVisits++,await chrome.storage.sync.set({[o.STATS]:h}),this.removeOverlay()}catch{this.removeOverlay()}}async handleClose(){try{let e=(await chrome.storage.sync.get(o.STATS))[o.STATS]||{...d};e.temptationsResisted++,await chrome.storage.sync.set({[o.STATS]:e}),chrome.runtime.sendMessage({type:"CLOSE_TAB"})}catch{chrome.runtime.sendMessage({type:"CLOSE_TAB"})}}setupMutationObserver(){this.mutationObserver=new MutationObserver(t=>{for(let e of t)for(let i of e.removedNodes)if(i===this.shadowHost){this.shouldShowNudge().then(s=>{s&&setTimeout(()=>{document.getElementById("nudge-overlay-host")||(this.shadowHost=null,this.shadowRoot=null,this.injectOverlay())},50)});return}}),this.mutationObserver.observe(document.documentElement,{childList:!0})}removeOverlay(){this.clearTimer(),this.mutationObserver&&(this.mutationObserver.disconnect(),this.mutationObserver=null),document.removeEventListener("keydown",this.handleKeyDown),this.shadowHost?.parentNode&&this.shadowHost.parentNode.removeChild(this.shadowHost),this.shadowHost=null,this.shadowRoot=null,document.body.style.overflow=""}};document.readyState==="loading"?document.addEventListener("DOMContentLoaded",()=>new c().init()):new c().init();})();
